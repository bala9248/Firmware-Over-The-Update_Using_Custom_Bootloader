/**
 * @file     crc.c
 * @brief   This source file consists of function definitions for CRC function
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand CRC functionality
 * 1) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */

#include "crc.h"

#define INITIAL_CRC_VALUE   0xFFFFFFFF
#define CRC_MASK_VALUE      0x80000000
#define CRC_POLYNOMIAL      0x04C11DB7
#define VERIFY_CRC_FAIL     1
#define VERIFY_CRC_SUCCESS  0
#define NUMBER_OF_BITS     32


/**
  * @brief: Function to accumulate the controller crc
  * @param1: The input byte
  * @param2: The length of the data byte
  * @return crc value
  */
int accumulate(int data, uint32_t length)
{
	 int CRC = INITIAL_CRC_VALUE ;

	    for(int i=0; i< length;i++)
	    {
	        CRC = CRC ^ data;
	        for(int j=0;j< NUMBER_OF_BITS;j++)
	        {
	            if(CRC & CRC_MASK_VALUE)
	            {
	                CRC = (CRC << 1) ^ CRC_POLYNOMIAL; /*EX ored bit by bit of the polynomial if MSB bit is 1*/
	            }
	            else
	            {
	                CRC = (CRC << 1);			   /*Left shift by 1 if MSB bit is 0*/
	            }
	        }
	    }
	    return CRC;
}


/**
  * @brief: verify if host CRC matches with controller CRC
  * @param1: The input byte
  * @param2: The length of the data byte
  * @param3: host crc
  * @return crc matches / not
  */
uint8_t verifyCRC (int data, uint32_t length, uint32_t host_crc)
{
    int controller_CRCValue=0x00;

    controller_CRCValue= accumulate(data, length);
	if( controller_CRCValue == host_crc)
	{
	return VERIFY_CRC_SUCCESS;					/*Comparing the host CRC and controller CRC */
	}
	return VERIFY_CRC_FAIL;
}


