/**
 * @file    flashoperations.c
 * @brief   This source file consists of function definitions for the flash operations
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand flash registers
 * 1) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */


#include "flashoperations.h"


#define FLASH_SIZE_BYTE 		 0x00
#define FLASH_KEY1               0x45670123U
#define FLASH_KEY2               0xCDEF89ABU
#define FLASH_OPT_KEY1           0x08192A3BU
#define FLASH_OPT_KEY2           0x4C5D6E7FU
#define FLASH_CR_PSIZE           (0x3UL << 8U)


#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))
#define READ_BIT(REG, BIT)    ((REG) & (BIT))
#define WRITE_REG(REG, VAL)   ((REG) = (VAL))

#define OK                       1
#define ERROR					 0


/**
  * @brief Used to Unlock the flash
  * @return if flash is unlocked or not
  */
bool flashUnlock()
{
  static bool status= 0;
  if(READ_BIT(FLASH->CR, FLASH_CR_LOCK) != RESET)
  {

    WRITE_REG(FLASH->KEYR, FLASH_KEY1);				/*Flash Unlocks after writing this values to Flash key register*/
    WRITE_REG(FLASH->KEYR, FLASH_KEY2);
    status = OK;
  }

  return status;
}

/**
  * @brief Used to Unlock the flash
  * @return if flash is unlocked or not
  */
void flashLock()
{
	  FLASH->CR |= FLASH_CR_LOCK;			/*The MSB bit of Flash Control Register is set as 1*/
}


/**
  * @brief Used to erase a sector
  * @param1 The sector number
  * @return none
  */
void flashEraseSector(uint8_t sector_number)
{
	static int program_size=0;
	program_size= FLASH_SIZE_BYTE;
	CLEAR_BIT(FLASH->CR, FLASH_CR_PSIZE);
	FLASH->CR |= program_size;										/*Selecting the erase mode byte,half word, word, double word*/
	CLEAR_BIT(FLASH->CR, FLASH_CR_SNB);							/*Selecting the sector number*/
	FLASH->CR |= FLASH_CR_SER | (sector_number << FLASH_CR_SNB_Pos);   /*Sector erase command is activated*/
	FLASH->CR |= FLASH_CR_STRT;									/*Starting the erase operation*/

}

/**
  * @brief To write a byte to the flash
  * @param1 Address where the data should be written
  * @param2 The data to be written
  * @return none
  */
void flashWriteByte(int address, int data)
{

	  CLEAR_BIT(FLASH->CR, FLASH_CR_PSIZE);    /*Clearing the program size bit*/
	  FLASH->CR |= FLASH_SIZE_BYTE;		   /* Setting the program size byte as 1 byte*/
	  FLASH->CR |= FLASH_CR_PG;					/*Enabling programming bit*/
	  *(uint8_t*)address = data;			/*Storing the data to the specified address*/

}

/**
  * @brief To read a byte from flash
  * @param1 Address where the data should be read
  * @return The read data
  */
int flashReadByte(int address)
{
	static int data = 0;
	data = *(uint8_t*) (address);
	return data;
}

