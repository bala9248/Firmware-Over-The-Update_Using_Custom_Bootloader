/*
 * utils.h
 *
 *  Created on: Dec 11, 2021
 *      Author: prabh
 */

#ifndef UTILS_H_
#define UTILS_H_

#include "stdarg.h"
#include "string.h"
#include "stdint.h"


void print_cmd(char *format,...);
void print_debug(char *format,...);

#endif /* UTILS_H_ */
