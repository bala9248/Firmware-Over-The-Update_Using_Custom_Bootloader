/**
 * @file    bootloader.h
 * @brief   This header file consists of function prototypes for custom bootloader functions
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand flash memory
 * 1) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */

#include "main.h"
#include "fatfs.h"
#include "stdarg.h"
#include "string.h"
#include "stdint.h"
#include "fatfs_sd.h"
#include <stdbool.h>


/**
* @brief: To read data from bluetooth through UART
* @return none
*/
void bootloader_readdata();
/**
* @brief To jump to user application
* @return none
*/
void bootloader_jumpuserapp();

/**
  * @brief: To send acknowledgment
  * @param1: The bootloader function for which acknowledgment should be sent
  * @param2: The length of the data byte
  * @return none
  */
void bootloader_send_ack(uint8_t command_code, uint8_t follow_len);

/**
  * @brief: To send non acknowledgment
  * @param1: The bootloader function for which acknowledgment should be sent
  * @param2: The length of the data byte
  * @return none
  */
void bootloader_send_nack();

/**
  * @brief: To transmit data through UART
  * @param1 : The data to be transmitted
  * @param2: The length of the data byte
  * @return none
  */
void bootloader_uart_write_data(uint8_t *pBuffer, uint32_t len);

/**
* @brief Checking button state to know whether FW has to be updated or reverted
* @return none
*/
void checkButtonPress();

/**
  * @brief To erase user application
  * @return none
  */
void eraseUserApplication();

/**
  * @brief: To read the status of the GPIO pin
  * @param1: The GPIO port
  * @param2: The GPIO pin
  * @return the status of the GPIO pin
  */
int readGPIOPin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);

/**
  * @brief: Execute function to write data to the flash memory
  * @param1 : The data to be flashed
  * @param2 : The memory adress where data should be written
  * @param3 : The length of the data to be written
  * @return : the write status
  */
uint8_t execute_mem_write(uint8_t *pBuffer, uint32_t mem_address, uint32_t len);

