/*
 * utils.c
 *
 *  Created on: Dec 11, 2021
 *      Author: prabh
 */

#ifndef UTILS_C_
#define UTILS_C_

#include "utils.h"



void print_cmd(char *format,...)												// print function using variable argument list through UART 2
{		static char str[80];
		va_list args;
		va_start(args, format);
		vsprintf(str, format,args);
		printf(str);
		va_end(args);
}

void print_debug(char *format,...)												// print function using variable argument list through UART 6

{	char str[80];
	va_list args;
	va_start(args, format);
	vsprintf(str, format,args);
	printf(str);
	va_end(args);
}

#endif /* UTILS_C_ */
