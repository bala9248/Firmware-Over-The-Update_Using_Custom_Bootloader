/**
 * @file    uart.c
 * @brief   This source file consists of function definitions for UART functions functions
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand UART peripherals of STM32
 * 1) https://github.com/xpacks/stm32f4-hal
 * 2) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */


#include "uart.h"

#define ERROR 0
#define    OK 1
#define  BUSY 2
#define UART_READY 3

/**
  * @brief  Sends an amount of data in blocking mode.
  * @param  huart  Pointer to a UART_HandleTypeDef structure that contains
  *                the configuration information for the specified UART module.
  * @param  data_byte Pointer to data buffer
  * @param  Size Amount of data to be sent
  * @param  Timeout Timeout duration
  * @return  status
  */
int transmitUART(UART_HandleTypeDef *huart, uint8_t *data_byte, uint16_t Size, uint32_t Timeout)
{
  static uint16_t *temp_data;


  /* Check that a Tx process is not already ongoing */
  if (huart->gState == UART_READY)
  {
    if ((data_byte == NULL) || (Size == 0U))
    {
      return  ERROR;
    }

    huart->gState = BUSY;


    huart->TxXferSize = Size;
    huart->TxXferCount = Size;
    while (huart->TxXferCount > 0U)
    {
      huart->TxXferCount--;
      if (huart->Init.WordLength == UART_WORDLENGTH_9B)
      {

        temp_data = (uint16_t *) data_byte;
        huart->Instance->DR = (*temp_data & (uint16_t)0x01FF);
        if (huart->Init.Parity == UART_PARITY_NONE)
        {
          data_byte += 2U;
        }
        else
        {
          data_byte += 1U;
        }
      }
      else
      {
        huart->Instance->DR = (*data_byte++ & (uint8_t)0xFF);
      }
    }


    /* At end of Tx process, restore State to Ready */
    huart->gState = UART_READY;



    return OK;
  }
  else
  {
    return BUSY;
  }
}

/**
  * @brief  Receives an amount of data in blocking mode.
  * @param  huart  Pointer to a UART_HandleTypeDef structure that contains
  *                the configuration information for the specified UART module.
  * @param  data_byte Pointer to data buffer
  * @param  Size Amount of data to be received
  * @param  Timeout Timeout duration
  * @return status
  */
int receiveUART(UART_HandleTypeDef *huart, uint8_t *data_byte, uint16_t Size, uint32_t Timeout)
{
  uint16_t temp_data;


  if (huart->RxState == UART_READY)			 /* Check that a Rx process is not already ongoing */
  {
    if ((data_byte == NULL) || (Size == 0U))
    {
      return  ERROR;
    }
    huart->RxState = BUSY;


    huart->RxXferSize = Size;
    huart->RxXferCount = Size;

    /* Check the remain data to be received */
    while (huart->RxXferCount > 0U)
    {
      huart->RxXferCount--;
      if (huart->Init.WordLength == UART_WORDLENGTH_9B)
      {

        temp_data = (uint16_t *) data_byte;
        if (huart->Init.Parity == UART_PARITY_NONE)
        {
          temp_data = (uint16_t)(huart->Instance->DR & (uint16_t)0x01FF);
          data_byte += 2U;
        }
        else
        {
          temp_data = (uint16_t)(huart->Instance->DR & (uint16_t)0x00FF);
          data_byte += 1U;
        }

      }
      else
      {

        if (huart->Init.Parity == UART_PARITY_NONE)
        {
          *data_byte++ = (uint8_t)(huart->Instance->DR & (uint8_t)0x00FF);
        }
        else
        {
          *data_byte++ = (uint8_t)(huart->Instance->DR & (uint8_t)0x007F);
        }

      }
    }

    /* At end of Rx process, restore huart->RxState to Ready */
    huart->RxState = UART_READY;



    return OK;
  }
  else
  {
    return BUSY;
  }
}
