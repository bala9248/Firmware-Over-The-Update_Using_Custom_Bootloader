/**
 * @file    bootloader.c
 * @brief   This source file consists of function definitions for custom bootloader functions
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand flash memory
 * 1) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */

#include "bootloader.h"
#include "flashoperations.h"
#include "crc.h"
#include "utils.h"
#include "uart.h"
#include "OLED.h"

/*Function headers*/
#define FLASH_SECTOR2_BASE_ADDRESS 0x08008000U
#define BL_ACK 0xA5
#define BL_NACK 0x7F
#define OLD_FILE_SIZE 40284
#define FILE_SIZE 40372
#define BL_MEM_WRITE 0x23
#define GPIO_PIN0                 0x0001
#define GPIO_PIN13                0x2000


#define FLASH_SECTOR_0     0U /*!< Sector Number 0   */
#define FLASH_SECTOR_1     1U
#define FLASH_SECTOR_2     2U
#define FLASH_SECTOR_3     3U
#define FLASH_SECTOR_4     4U
#define FLASH_SECTOR_5     5U
#define FLASH_SECTOR_6     6U
#define FLASH_SECTOR_7     7U


/*UART structure handler*/

UART_HandleTypeDef huart2;
uint8_t data[OLD_FILE_SIZE];

FIL fil; 		  /* File */
FRESULT fresult;  /* result */
UINT br, bw;      /* File read/write count */



#define BUFFER_SIZE 6000
char buffer[BUFFER_SIZE];  					/* To store strings.. */
uint8_t b1_rx_buffer[200];					/* Copying the incoming data to a large buffer */
uint32_t flash_finish=0;


/**
  * @brief Checking button state to know whether FW has to be updated or reverted
  * @return none
  */
void checkButtonPress()
{
	while(1)
	{

  	  if (readGPIOPin(GPIOA, GPIO_PIN0))			/*Manual way of staying in bootloader code checks if PA0 is set */
  	  {
  		 for(int i=0; i < OLD_FILE_SIZE;i++)
  		 {
  			 data[i]= flashReadByte(FLASH_SECTOR2_BASE_ADDRESS + i);
  		 }
  		 fresult = f_open(&fil, "file1.bin", FA_CREATE_ALWAYS | FA_WRITE);
  		 fresult = f_write(&fil, data, OLD_FILE_SIZE, &bw);
  		 f_close(&fil);
  		 for(int i=0; i < OLD_FILE_SIZE;i++)
  		 {
  		     data[i]= 0;
  		 }
  		 OLED_Init ();
  		 OLED_Putstr_minimal("F/W Updating...");
		 eraseUserApplication();
		 print_cmd("Button is pressed, staying in bootloader\r\n");
  		 bootloader_readdata();									/* Jumping to bootloader functions */
  	  }
  	  else if (readGPIOPin(GPIOC, GPIO_PIN13))
  	  {

  		  fresult = f_open(&fil, "file1.bin", FA_READ | FA_WRITE);
  		  f_read (&fil, data,OLD_FILE_SIZE, &br);
  		  f_close(&fil);
  		  OLED_Putstr_minimal("F/W Reverting...");
 		  eraseUserApplication();
 		  int memory_address = FLASH_SECTOR2_BASE_ADDRESS;
 		  flashUnlock();
 		  for(uint32_t i = 0 ; i <OLD_FILE_SIZE ; i++)
 		  {
 			flashWriteByte(memory_address+i,data[i] );		 /*programming flash byte by byte*/
  	        flash_finish++;
 		   }
  	      flashLock();
  	      bootloader_jumpuserapp();
  	  }
  	  else
  	  {
  		  bootloader_jumpuserapp();
  	  }
}
}

/**
  * @brief To jump to user application
  * @return none
  */
void bootloader_jumpuserapp()
{
	void (*app_reset_handler)(void);                                  /*Initialization of function pointer*/
	print_debug("Debug Message: jumping to user application");
	uint32_t msp_value=*(volatile uint32_t *)FLASH_SECTOR2_BASE_ADDRESS;/*Setting MSP value of SECTOR 2 located in 1 byte*/
	print_debug("Debug Message: MSP value :%#x\n",msp_value);
	__set_MSP(msp_value);
	uint32_t resethandler_address=*(volatile uint32_t *)(FLASH_SECTOR2_BASE_ADDRESS+4);  /*Setting Reset handler of SECTOR 2 located in 2nd byte*/
	app_reset_handler=(void*) resethandler_address;                    /*Assigning function pointer with reset handler address*/
	app_reset_handler();

}

/**
  * @brief: To read data from bluetooth through UART
  * @return none
  */
void bootloader_readdata()
{
	uint8_t rcv_len=0;
	while(1)
	{
		memset(b1_rx_buffer,0,200);									/* Filling a block of memory with value 0 */
		receiveUART(&huart2, b1_rx_buffer,1, HAL_MAX_DELAY);	/* Receiving the number of packets to follow */
		rcv_len=b1_rx_buffer[0];
		receiveUART(&huart2, &b1_rx_buffer[1],rcv_len,HAL_MAX_DELAY); /*Receiving the subsequent bytes */
		switch(b1_rx_buffer[1])
		{
		case BL_MEM_WRITE:
			bootloader_handle_mem_write_cmd(b1_rx_buffer);
		break;

		default:
			print_debug("Debug Message : Invalid_command ");
		break;
	}
}
}

/**
  * @brief: To handler function for flash write
  * @param : The data to be flashed
  * @return none
  */
void bootloader_handle_mem_write_cmd(uint8_t *pBuffer)
{

	uint8_t write_status = 0x00;									                /*To check the status whether a byte has been flashed*/
	uint8_t payload_length = pBuffer[6];												/*Checking the payload length in 6th byte*/
	uint32_t memory_address = *((uint32_t *) ( &pBuffer[2]) );							/*Stripping the memory address from the packet*/
	uint32_t command_packet_length = b1_rx_buffer[0]+1 ;								/*Total length of the command packet including 0th element*/
	uint32_t host_crc = *((uint32_t * ) (&b1_rx_buffer[0]+command_packet_length - 4) ) ; /*Extract the CRC32 sent by the Host*/
	if (! verifyCRC(b1_rx_buffer[0],command_packet_length-4,host_crc))    //Checking CRC
	{
		bootloader_send_ack(pBuffer[0],1);
        write_status = execute_mem_write(&pBuffer[7],memory_address, payload_length);
        bootloader_uart_write_data(&write_status,1);							/*Sending status to host*/
    }
	else
	{
		bootloader_send_nack();
	}

}

/**
  * @brief: Execute function to write data to the flash memory
  * @param1 : The data to be flashed
  * @param2 : The memory adress where data should be written
  * @param3 : The length of the data to be written
  * @return the write status
  */
uint8_t execute_mem_write(uint8_t *pBuffer, uint32_t mem_address, uint32_t len)
{
    uint8_t status=HAL_OK;
    flashUnlock();
    for(uint32_t i = 0 ; i <len ; i++)
    {

        flashWriteByte(mem_address+i,pBuffer[i] ); 							/*programming flash byte by byte*/
        flash_finish++;
    }
    flashLock();
    if(flash_finish == FILE_SIZE)									/*Programming whether all the bytes are programmed*/
    {
    	OLED_Putstr_minimal("F/W Update");
        OLED_Putstr_minimal ("Successful!!!");
        bootloader_jumpuserapp();
     }
    return status;

}

/**
  * @brief: To transmit data through UART
  * @param1 : The data to be transmitted
  * @param2: The length of the data byte
  * @return none
  */
void bootloader_uart_write_data(uint8_t *pBuffer, uint32_t len)
{
	transmitUART(&huart2,pBuffer,len,HAL_MAX_DELAY);
}

/**
  * @brief: To send acknowledgment
  * @param1: The bootloader function for which acknowledgment should be sent
  * @param2: The length of the data byte
  * @return none
  */
void bootloader_send_ack(uint8_t command_code, uint8_t follow_len)
{
	uint8_t ack_buf[2];
	ack_buf[0]=BL_ACK;
	ack_buf[1]=follow_len;
	transmitUART(&huart2, ack_buf,2,HAL_MAX_DELAY);
}

/**
  * @brief: To send non acknowledgment
  * @param1: The bootloader function for which acknowledgment should be sent
  * @param2: The length of the data byte
  * @return none
  */
void bootloader_send_nack()
{
	uint8_t nack=BL_NACK;
	transmitUART(&huart2,&nack,1,HAL_MAX_DELAY);

}

/**
  * @brief To erase user application
  * @return none
  */
void eraseUserApplication()
{
	flashUnlock();
	flashEraseSector(FLASH_SECTOR_2); /*Erasing Sector 2 before flashing */
	flashEraseSector(FLASH_SECTOR_3);
	flashEraseSector(FLASH_SECTOR_4);
	flashLock();
}


/**
  * @brief: To read the status of the GPIO pin
  * @param1: The GPIO port
  * @param2: The GPIO pin
  * @return the status of the GPIO pin
  */
int readGPIOPin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
{
  GPIO_PinState bitstatus;
  if((GPIOx->IDR & GPIO_Pin) != (uint32_t)GPIO_PIN_RESET)
  {
    bitstatus = GPIO_PIN_SET;
  }
  else
  {
    bitstatus = GPIO_PIN_RESET;
  }
  return bitstatus;
}

