/**
 * @file    main.c
 * @brief   This source file consists of function definitions for peripheral initialization and calling the bootloader
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference for peripheral initialization
 * 1) https://github.com/xpacks/stm32f4-hal
 * 2) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */

#include "main.h"
#include "OLED.h"
#include "bootloader.h"
#include "fatfs.h"
#include "fatfs_sd.h"

						/*Peripheral strcuture Handlers*/
CRC_HandleTypeDef hcrc;
SPI_HandleTypeDef hspi1;
UART_HandleTypeDef huart2;
I2C_HandleTypeDef hi2c1;
FATFS fs;  					/* file system */
FRESULT fresult;  			/* result */


/*Functions definitions are given in the bottom of this file*/

void configureSystemClock();
static void initializeGPIO();
static void initializeUART();
static void peripheralsInitialize();
static void initializeOLED();
static void initializeSPI(void);
static void initializeI2C(void);


/**
  * @brief Calls the initialization function and button press function used in bootloader.c
  * @return none
  */
int main(void)
{
	peripheralsInitialize();
	fresult = f_mount(&fs, "", 1);
	initializeOLED();
	checkButtonPress();
}


/**
  * @brief Initialize all the hardware peripherals
  * @return none
  */
void peripheralsInitialize()
{
	configureSystemClock();
	initializeGPIO();
	initializeUART();
	initializeSPI();
	initializeI2C();
	MX_FATFS_Init();

}

/**
  * @brief Initialize OLED screen
  * @return none
  */
void initializeOLED()
{
	OLED_Init ();
	OLED_GotoXY (10,0); /* goto 10, 10 */
	OLED_Putstr ("Choose option");
	OLED_GotoXY (10,20); /* goto 10, 20 */
	OLED_Putstr ("Blue-New F/w");
    OLED_GotoXY (10,40); /* goto 10, 40 */
	OLED_Putstr ("Yellow-Old FW");
}

/**
  * @brief System Clock Configuration
  * @return None
  */
void configureSystemClock()
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

}


/**
  * @brief I2C1 Initialization Function
  * @param None
  * @return None
  */
static void initializeI2C(void)
{
  /* I2C parameters configuration*/
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @return None
  */
static void initializeSPI(void)
{

  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @return None
  */
static void initializeUART(void)
{
  /* UART parameter configuration*/
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;

}

/**
  * @brief Writing a GPIO pin to logic HIGH / logic low
  * @param None
  * @return None
  */
void writeGPIOPin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIO_PinState PinState)
{
  if(PinState != GPIO_PIN_RESET)
  {
    GPIOx->BSRR = GPIO_Pin;
  }
  else
  {
    GPIOx->BSRR = (uint32_t)GPIO_Pin << 16U;
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @return None
  */
static void initializeGPIO(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  writeGPIOPin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  writeGPIOPin(GPIOD, GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD14 PD15 */
  GPIO_InitStruct.Pin = GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}


