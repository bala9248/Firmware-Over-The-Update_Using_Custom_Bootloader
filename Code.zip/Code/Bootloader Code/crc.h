/**
 * @file    crc.c
 * @brief   This header file consists of function prototypes for CRC function
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand CRC functionality
 * 1) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */

#ifndef CRC_H_
#define CRC_H_
#include "stdint.h"




/**
  * @brief: Function to accumulate the controller crc
  * @param1: The input byte
  * @param2: The length of the data byte
  * @return crc value
  */
int accumulate(int data, uint32_t length);

/**
  * @brief: verify if host CRC matches with controller CRC
  * @param1: The input byte
  * @param2: The length of the data byte
  * @param3: host crc
  * @return crc matches / not
  */
uint8_t verifyCRC (int data, uint32_t length, uint32_t host_crc);

#endif /* CRC_H_ */
