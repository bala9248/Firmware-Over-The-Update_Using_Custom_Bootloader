/**
 * @file    flashoperations.h
 * @brief   This header file consists of function prototypes for the flash operations
 * @date 	1st December, 2021
 * @author 	Shreyan Prabhu
 * @Tools   STM32CubeIDE
 * @References :  Used the below link as a reference to understand flash registers
 * 1) https://www.st.com/resource/en/reference_manual/dm00119316-stm32f411xc-e-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf
 */

#ifndef FLASHOPERATIONS_H_
#define FLASHOPERATIONS_H_


#include "stm32f4xx_hal.h"
#include <stdbool.h>

/**
  * @brief Used to Unlock the flash
  * @return if flash is unlocked or not
  */
bool flashUnlock();


/**
  * @brief Used to Unlock the flash
  * @return if flash is unlocked or not
  */
void flashLock();

/**
  * @brief Used to erase a sector
  * @param1 The sector number
  * @return none
  */
void flashEraseSector(uint8_t sector_number);

/**
  * @brief To write a byte to the flash
  * @param1 Address where the data should be written
  * @param2 The data to be written
  * @return none
  */
void flashWriteByte(int address, int data);

/**
  * @brief To read a byte from flash
  * @param1 Address where the data should be read
  * @return The read data
  */
int  flashReadByte(int address);

#endif /* FLASHOPERATIONS_H_ */
