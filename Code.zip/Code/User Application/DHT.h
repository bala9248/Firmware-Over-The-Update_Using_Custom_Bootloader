/*
*@File: DHT.h
*Initializes and Acquires data from the DHT22 sensor
*
*@Author: Balapranesh Elango
*@Date : 11/12/2021
*@Version 1.0
*
*References: https://www.youtube.com/watch?v=2kjU7sHFSM0
*
*/
#ifndef INC_DHT_H_
#define INC_DHT_H_

/*
*@Function:  DHT_GetData(float *Temperature, float *Humidity)
*@Brief:     Gets one reading of temperature and humidity
*Parameters: Temperature and Humidity -- Passed by reference
*Returns:    None
*/
void DHT_GetData (float *Temperature, float *Humidity);

#endif /*  INC_DHT_H_ */
