/*
*@File: DHT.c
*Initializes and Acquires data from the DHT22 sensor
*
*@Author: Balapranesh Elango
*@Date : 11/12/2021
*@Version 1.0
*
*References: https://www.youtube.com/watch?v=2kjU7sHFSM0
*
*/

#include "stm32f4xx_hal.h"
#include "DHT.h"
#include "timer.h"
#include "GPIO.h"

/*********************#define Macros**************************/
#define   DHT_PORT   GPIOA        //GPIO port A
#define   DHT_PIN    GPIO_PIN_1   //GPIO pin 1
#define   ERROR      (-1)
#define   NO_ERR	 (1)




/*
*@Function:  int DHT_Init()
*@Brief:     Initializes the DHT sensor using the DHT22 initialization sequence
*Parameters: None
*Returns:    None
*/
static int DHT_Init()
{
	init_systick();

	//Dht22 init sequence
	GPIO_Output (DHT_PORT, DHT_PIN);         // set PA1 as output
	GPIOA->BSRR = (uint32_t)DHT_PIN << 16U;   // pull the pin low for atleast 1ms
	systick_delay(1100);
	GPIOA->BSRR = DHT_PIN;                      // pull the line high for 30ms
	systick_delay(30);
	GPIO_Input(DHT_PORT, DHT_PIN);           // set PA1 as input


	uint8_t error_status = 0;
	systick_delay (40);
	if (!(HAL_GPIO_ReadPin (DHT_PORT, DHT_PIN)))   //PA1 pulled low by PA1
	{
		systick_delay(80);
		if ((HAL_GPIO_ReadPin (DHT_PORT, DHT_PIN))) //PA1 pulled high by PA1
			error_status = NO_ERR;
		else
			error_status = ERROR;
	}
	while ((HAL_GPIO_ReadPin (DHT_PORT, DHT_PIN)))
		;//wait for PA1 to go low

	return error_status;  //Error status
}


/*
*@Function:  int DHT_Read()
*@Brief:     Reads a byte of data from the DHT22
*Parameters: None
*Returns:    rx_byte -> the received byte from the DHT22
*/
static uint8_t DHT_Read()
{
	uint8_t rx_byte = 0x00;
	for (int i = 0; i < 8; i++)
	{
		while (!(HAL_GPIO_ReadPin (DHT_PORT, DHT_PIN)))
			;//wait for PA1 to go high
		systick_delay(40);

		if ((HAL_GPIO_ReadPin (DHT_PORT, DHT_PIN)))  //Check if pin is HIGH
			rx_byte |= (1 << (7-i)); //Set MSB to 1

		//No need to check for LOW as rx_byte is initialized as 0

		while ((HAL_GPIO_ReadPin (DHT_PORT, DHT_PIN)))
			;//Wait for pin to go LOW
	}
	return rx_byte; //Return received byte
}


/*
*@Function:  DHT_GetData(float *Temperature, float *Humidity)
*@Brief:     Gets one reading of temperature and humidity
*Parameters: Temperature and Humidity -- Passed by reference
*Returns:    None
*/
void DHT_GetData(float *Temperature, float *Humidity)
{
    int error_status = DHT_Init(); //DHT22 init sequence
    if(error_status == ERROR){
    	return;
    }

    uint8_t humi_byte1, humi_byte2, temp_byte1, temp_byte2, check_sum;
    //40 Bits of data is stored as shown below
    humi_byte1 = DHT_Read();
    humi_byte2 = DHT_Read();
    temp_byte1 = DHT_Read();
    temp_byte2 = DHT_Read();
    check_sum  = DHT_Read();

	if (check_sum == (humi_byte1+humi_byte2+temp_byte1+temp_byte2))  //If check sum is valid
	{
			*Temperature = (float)((temp_byte1<<8)|temp_byte2)/(float)10;
			*Humidity = (float)((humi_byte1<<8)|humi_byte2)/(float)10;

	}
}


