/**
 *
 * @file    GPIO.c
 * @brief   Contains the code to initialize GPIO pins as input or output
 * @Author  Balapranesh Elango
 *
 */
#include "stm32f4xx_hal.h"
#include "GPIO.h"


/*
*@Function:  Init_GPIO()
*@Brief:     Initalizes the required GPIO pin
*Parameters: None
*Returns:    None
*/
void Init_GPIO(){

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /**Init PA1**/
  SET_BIT(RCC->AHB1ENR, RCC_AHB1ENR_GPIOAEN); //Enable clock gating to the GPIO pin
  GPIOA->BSRR = (uint32_t)GPIO_PIN_1 << 16U; //Reset the GPIO Pin before configuring it

  //Configuring the PA1 as output pin as it will initially be used as an output pin in DHT22
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /**Init PD12 -- LED**/
  SET_BIT(RCC->AHB1ENR, RCC_AHB1ENR_GPIODEN); //Enable clock gating to the GPIO pin
  GPIOA->BSRR = (uint32_t)GPIO_PIN_12 << 16U; //Reset the GPIO Pin before configuring it

  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}

/*
*@Function:  void GPIO_Output(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin)
*@Brief:     Setting the pin as an output
*Parameters: GPIO_TypeDef *GPIO_Port --> GPIO port, uint16_t GPIO_Pin --> GPIO pin
*Returns:    None
*/
void GPIO_Output(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin){

	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIO_Port, &GPIO_InitStruct);
}

/*
*@Function:  void GPIO_Input(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin)
*@Brief:     Setting the pin as an input
*Parameters: GPIO_TypeDef *GPIO_Port --> GPIO port, uint16_t GPIO_Pin --> GPIO pin
*Returns:    None
*/
void GPIO_Input(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin){

	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIO_Port, &GPIO_InitStruct);
}
