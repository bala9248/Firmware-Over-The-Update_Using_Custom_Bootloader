/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  * @author			: Balapranesh Elango
  ******************************************************************************
  *Interface Instructions:
  *
                STM32F411VE
             -----------------
            |                 |
            |                 |
            |                 |
            |                 |
            |              PA1|-->DHT22 Pin 2
            |                 |
	        |                 |
	        |              PB7|-->SDA OLED
	        |              PB6|-->SCL OLED
	        |                 |
	        |                 |
	        |                 |
	        |                 |
	        |                 |
	        |                 |
	        -------------------
  *
  ******************************************************************************
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "OLED.h"
#include "GPIO.h"
#include "main.h"
#include "DHT.h"
#include "I2C.h"
#include "timer.h"


bool error_status = false;

void SystemClock_Config(void);

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	float Temperature, Humidity;
    HAL_Init();
    SystemClock_Config();
    Init_GPIO();
    Init_I2C();
    char txDataTemperature[30];
    char txDataHumidity[30];

    while (1)
    {
    	  DHT_GetData(&Temperature, &Humidity); //Get the temperature and humidity data
    	  systick_delay_ms(3000);               //3 second delay
    	  //Convert values to string to be printed
    	  sprintf(txDataTemperature,"Temp = %.2f", Temperature);
    	  sprintf(txDataHumidity,"Humidity = %.2f", Humidity);

    	  //Toggle LED
    	  if ((GPIOD->ODR & GPIO_PIN_12) == GPIO_PIN_12)
    	    GPIOD->BSRR = (uint32_t)GPIO_PIN_12 << 16U;
    	  else
    	    GPIOD->BSRR = GPIO_PIN_12;

    	  OLED_Init ();
    	  OLED_GotoXY (10,0);
    	  OLED_Putstr("Weather Monitor");
          OLED_GotoXY (10,20);
    	  OLED_Putstr(txDataTemperature);
    	  OLED_GotoXY (10, 40);
    	  OLED_Putstr(txDataHumidity);
    }
}


/** SystemClock_Config(void)
  * @brief System Clock Configuration
  * @returns None
  * @param   None
  *
  * Written using the clock configuration GUI in the IDE
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}




/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
	error_status = true;
}
