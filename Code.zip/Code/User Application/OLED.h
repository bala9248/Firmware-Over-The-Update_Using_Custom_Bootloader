/*
*@File: OLED.h
*SSD1306 minimalistic OLED driver to write strings in the display
*
*@Author: Balapranesh Elango
*@Date : 11/6/2021
*@Version 1.0
*
*References: https://github.com/vadzimyatskevich/STM32F103_SSD1306/blob/master/Src/ssd1306.c
*
*Leveraged Section: font_data array values
*
*/
#ifndef INC_OLED_H_
#define INC_OLED_H_

#include "stm32f4xx_hal.h"


/*
*@Function:  OLED_Clear()
*@Brief:     To clear the OLED display
*Parameters: None
*
*Returns:    None
*/
void OLED_Clear (void);


/*
*@Function:  Oled_Init()
*@Brief:     Initializes the OLED display
*Parameters: None
*Returns:    None
*/
void OLED_Init(void);

/*
*@Function: OLED_FillPixel(uint16_t x, uint16_t y, int color)
*@Brief:    Draws a pixel with the input color
*Parameters:(x,y) -> Pixel location; color -> Color to be written
*Returns:   None
*/
void OLED_FillPixel(uint16_t x, uint16_t y, int color) ;

/*
*@Function:  OLED_Putchar(char ch, int color)
*@Brief:     To write a character to the display
*Parameters: ch -> character to be written
*
*Returns:    None
*/
void OLED_Putchar(char ch);

/*
*@Function:  OLED_Putstr(char* str)
*@Brief:     To write a string to the display, calls putchar
*Parameters: *str -> str to be written
*
*Returns:    None
*/
void OLED_Putstr(char* str);



/*
*@Function:  OLED_GotoXY(uint16_t x, uint16_t y)
*@Brief:     Updates the CurrentX, CurrentY variables
*Parameters: (x,y) -> Pixel location
*Returns:    None
*/
void OLED_GotoXY(uint16_t x, uint16_t y);



#endif /* INC_OLED_H_ */
