/**
 *
 * @file    timer.c
 * @brief   Contains the systick timer and Interrupt functions
 *
 * @Author  Balapranesh Elango
 *
 */

#include "timer.h"

/*** Global variables**/
ticktime_t g_program_start; //time since beginning of program
ticktime_t g_timer_start;   //time since reset
ticktime_t g_time_usec;    //global variable to keep track of time in msec

/**** #define Macros****/
#define  PERIOD  16

/*
 * @void init_systick()
 * Initializes systick timer and Interrup
 * Returns : None
 * Paramaters : None
 */
void init_systick(){
	SysTick->LOAD = PERIOD;  //reload value = (16M / 16) Interrupts every 1usec
	SysTick->VAL = 0; //Reset VAL
	NVIC_SetPriority (SysTick_IRQn, 3);//Interrupt priority set to 3
	SysTick->CTRL = 0x7; // Enable systick, Enable interrupt, enable with processor clock
	//setting all global variables to 0
	g_time_usec = 0;
	g_program_start = g_timer_start = g_time_usec;

}


void SysTick_Handler(void){
	g_time_usec++; //Interrupts every 1 usec. So g_time_usec keeps track of time in usec
}


/*
 * @ticktime_t now()
 * returns the time since the program startup
 * Returns : returns the time since the program startup
 * Paramaters : none
 */
ticktime_t now(){
	return g_time_usec - g_program_start;//Time elapsed since the beginning
}

/*
 * @void reset_timer()
 * resets get_timer to 0 but does not affect now()
 * Returns : None
 * Paramaters : None
 */
void reset_timer(){
	g_timer_start = g_time_usec;//timer_start set to current time
}

/*
 * @ticktime_t get_timer()
 * returns the time since the last reset
 * Returns : returns the time since the last reset
 * Paramaters : none
 */
ticktime_t get_timer(){
	return g_time_usec - g_timer_start; //Time since last reset
}

/*
 * @void systick_delay(uint32_t delay_usec)
 * creates a delay in us of delay_sec
 * Returns : None
 * Paramaters : delay_usec: used to create delay
 */
void systick_delay(uint32_t delay_usec){
  ticktime_t curr_delay = g_time_usec;
  while ( (g_time_usec - curr_delay) <= delay_usec) //waits till delay time has elapsed
	  __asm volatile("NOP");
 }


/*
 * @void systick_delay_ms(uint32_t delay_msec)
 * creates a delay in ms of delay_sec
 * Returns : None
 * Paramaters : delay_msec: used to create delay
 */
void systick_delay_ms(uint32_t delay_msec){
	 ticktime_t curr_delay = g_time_usec;
	 while ( (g_time_usec - curr_delay) <= (delay_msec * 1000)) //waits till delay time has elapsed
	 	  __asm volatile("NOP");
}
