/**
 *
 * @file    GPIO.h
 * @brief   Contains the code to initialize GPIO pins as input or output
 * @Author  Balapranesh Elango
 *
 */
#ifndef INC_GPIO_H_
#define INC_GPIO_H_


/*
*@Function:  Init_GPIO()
*@Brief:     Initalizes the required GPIO pin
*Parameters: None
*Returns:    None
*/
void Init_GPIO();


/*
*@Function:  void GPIO_Output(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin)
*@Brief:     Setting the pin as an output
*Parameters: GPIO_TypeDef *GPIO_Port --> GPIO port, uint16_t GPIO_Pin --> GPIO pin
*Returns:    None
*/
void GPIO_Output(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin);


/*
*@Function:  void GPIO_Input(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin)
*@Brief:     Setting the pin as an input
*Parameters: GPIO_TypeDef *GPIO_Port --> GPIO port, uint16_t GPIO_Pin --> GPIO pin
*Returns:    None
*/
void GPIO_Input(GPIO_TypeDef *GPIO_Port, uint16_t GPIO_Pin);


#endif /* INC_GPIO_H_ */
