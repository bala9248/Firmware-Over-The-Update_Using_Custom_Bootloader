#ifndef INC_TIMER_H_
#define INC_TIMER_H_
/**
 * @file    timer.h
 * @brief   Contains the header file for timer.c
 * @Author  Balapranesh Elango
 */


#include "stm32f4xx_hal.h"
#include <stdio.h>

typedef uint32_t ticktime_t;

/*
 * @void init_systick()
 * Initializes systick timer and Interrup
 * Returns : None
 * Paramaters : None
 */
void init_systick();



/*
 * @void reset_timer()
 * resets get_timer to 0 but does not affect now()
 * Returns : None
 * Paramaters : None
 */
void reset_timer();


/*
 * @void delay(uint32_t delay_msec)
 * creates a delay of delay_msec
 * Returns : None
 * Paramaters : delay_msec: used to create delay
 */
void systick_delay(uint32_t delay_msec);


/*
 * @ticktime_t get_timer()
 * returns the time since the last reset
 * Returns : returns the time since the last reset
 * Paramaters : none
 */
ticktime_t get_timer();


/*
 * @ticktime_t now()
 * returns the time since the program startup
 * Returns : returns the time since the program startup
 * Paramaters : none
 */
ticktime_t now();


/*
 * @void systick_delay_ms(uint32_t delay_msec)
 * creates a delay in ms of delay_sec
 * Returns : None
 * Paramaters : delay_msec: used to create delay
 */
void systick_delay_ms(uint32_t delay_msec);

#endif /*INC_TIMER_H_*/
