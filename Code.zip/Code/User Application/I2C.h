/**
 * @file    I2C.h
 * @brief   Contains the Initialization of I2C1 and I2C write functions
 * @Author  Balapranesh Elango
 */


#ifndef INC_I2C_H_
#define INC_I2C_H_
#include "stm32f4xx_hal.h"


/*
*@Function:  void Init_I2C()
*@Brief:     I2C intialization function for I2C1 in fast mode
*Parameters: None
*Returns:    None
*/
void Init_I2C();


/*
*@Function:  I2C_TxByte(uint8_t reg, uint8_t data)
*@Brief:     performed I2C write of single byte to the specified slave addr
*Parameters: reg -> the register to write to
*Parameters: data -> the data to be written
*Returns:    None
*/
void I2C_TxByte(uint8_t reg, uint8_t data);

/*
*@Function:  I2C_TxBytes(uint8_t reg, uint8_t* data, uint16_t count)
*@Brief:     writes multiples byte to the specifies slave addr
*Parameters: reg -> the register to write to
*Parameters: data -> the data to be written
*Parameters: n -> Number of bytes
*Returns:    None
*/
void I2C_TxBytes(uint8_t reg, uint8_t *data, uint16_t count);



#endif /* INC_I2C_H_ */
