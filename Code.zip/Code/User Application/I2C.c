/**
 * @file    I2C.c
 * @brief   Contains the Initialization of I2C1 and I2C write functions
 * @Author  Balapranesh Elango
 *
 */
#include "I2C.h"
#include "timer.h"


I2C_HandleTypeDef hi2c1;

/************#define Macros*******************/
#define  SSD1306_I2C_ADDR          0x78
#define  FAST_MODE	               400000
#define  START_BIT				   0x0100        //I2C_CR1 register
#define  STOP_BIT                  0x0200        //I2C_CR1 register
#define  TX_OPTION_DEFAULT         0xFFFF0000U   // XferOptions default value
#define  READY_STATE               1             //Ready state
#define  BUSY_STATE                0             //Busy state
#define  I2C_MODE                  64            //mem mode
#define  TXE_FLAG			       0x08          //I2C->SR1 register
#define  FLAG_ADD10				   0x04          //I2C->SR1 register
#define  BYTE					   1

/*
*@Function:  I2C_Write(I2C_HandleTypeDef *hi2c, uint16_t addr, uint8_t *data, uint16_t Size)
*@Brief:     Performs an I2C write for the given data to the specified addr
*
*Parameters: hi2c -> I2C_HandleTypeDef
*Parameters: addr -> address to write to(register)
*Parameters: data -> data to be written
*Parameters: Size -> Size of the data to be written
*
*Returns:    1  on success
*Returns:    -1 on failure
*/
static int I2C_Write(I2C_HandleTypeDef *hi2c, uint16_t addr, uint8_t *data, uint16_t Size) {


   if (hi2c->State != READY_STATE)   //Check if I2C bus is busy
	  return -1;


    if ((hi2c->Instance->CR1 & I2C_CR1_PE) != I2C_CR1_PE){ //Check if I2C is enabled and enable if not enabled

    	hi2c->Instance->CR1 |= I2C_CR1_PE;
    }


    hi2c->State     = BUSY_STATE;       //To prevent I2C communication disruption by other devices
    hi2c->Mode      = I2C_MODE;         //Choosing I2C mode


    hi2c->Instance->CR1 |= START_BIT;  //Start bit is set in the I2C_RequestMemoryWrite() function
    hi2c->Instance->DR = I2C_7BIT_ADD_WRITE(SSD1306_I2C_ADDR);

    while ( !(hi2c->Instance->SR1 & FLAG_ADD10)) //Wait till ADD10 flag is set
    	;
    hi2c->Instance->SR1 &= ~ FLAG_ADD10; //Clear the ADD10 flag

	while ( !(hi2c->Instance->SR1 & TXE_FLAG) )
	  ;//Wait for Tx completion

	 hi2c->Instance->DR = I2C_MEM_ADD_LSB(addr);

	while ( !(hi2c->Instance->SR1 & TXE_FLAG) )
		  ;//Wait for Tx completion


    //Set all the transfer parameters
    hi2c->pBuffPtr    = data;
    hi2c->XferCount   = Size;    //Amount of data to be transfered
    hi2c->XferSize    = hi2c->XferCount; //T
    hi2c->XferOptions = TX_OPTION_DEFAULT;

    while(hi2c->XferSize) {

    	hi2c->Instance->DR = *hi2c->pBuffPtr; //Writing data to the data register
    	hi2c->pBuffPtr++; //Next data element
    	hi2c->XferSize--; //update counter
    	hi2c->XferCount--;

    	while ( !(hi2c->Instance->SR1 & TXE_FLAG) )
    	  ;//Wait for Tx completion
    }

    hi2c->Instance->CR1 |= STOP_BIT;//Stop Bit

    //Ready for next I2C transaction
    hi2c->State = HAL_I2C_STATE_READY;
    hi2c->Mode = HAL_I2C_MODE_NONE;

    return 1; //Success
 }





/*
*@Function:  void Init_I2C()
*@Brief:     I2C intialization function for I2C1 in fast mode
*Parameters: None
*Returns:    None
*/
void Init_I2C() {

  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = FAST_MODE;
  hi2c1.Init.DutyCycle = 0x00;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;

}


/*
*@Function:  void I2C_TxByte(uint8_t reg, uint8_t data)
*@Brief:     performed I2C write of single byte to the specified slave addr
*Parameters: reg -> the register to write to
*Parameters: data -> the data to be written
*Returns:    None
*/
void I2C_TxByte(uint8_t reg, uint8_t data) {

	I2C_Write(&hi2c1, reg, &data, BYTE);
}

/*
*@Function:  void I2C_TxBytes(uint8_t reg, uint8_t* data, uint16_t count)
*@Brief:     writes multiple bytes to the specified slave addr
*Parameters: reg -> the register to write to
*Parameters: data -> the data to be written
*Parameters: n -> Number of bytes
*Returns:    None
*/
void I2C_TxBytes(uint8_t reg, uint8_t* data, uint16_t n) {

	I2C_Write(&hi2c1, reg, data, n);
}
